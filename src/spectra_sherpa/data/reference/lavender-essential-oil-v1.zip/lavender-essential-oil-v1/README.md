# Lavender Essential Oil FTIR Corpus v1

This separately distributed dataset contains 33 Thermo Nicolet Avatar 370 OMNIC SPA files: 11 retained lavender essential-oil specimens acquired in three blocks. Spectra are absorbance with OMNIC correction set to None. Validate `SHA256SUMS` and `manifest.json` before use.

This is an original unpublished laboratory dataset. No external publication citations apply.

This dataset is not evidence of botanical authenticity, supplier identity, population performance, or performance on future lots. The software is distributed separately.
