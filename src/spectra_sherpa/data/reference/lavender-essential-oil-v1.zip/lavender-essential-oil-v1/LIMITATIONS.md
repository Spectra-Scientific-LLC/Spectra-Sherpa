# Limitations

- The 33 spectra are technical acquisition replicates of 11 retained lavender essential-oil specimens in three blocks, not independent population samples.
- Sample labels and author-reported statuses do not establish botanical authenticity, supplier identity, population performance, or performance on future lots.
- The corpus is intended for native-parser, reproducibility, visualization, PCA, and closed-set specimen-identification pipeline validation.
- The acquisition used absorbance with OMNIC Correction set to None; no spectral correction was applied at acquisition.
