# Attribution

Ye Feng. (2026). Lavender Essential Oil FTIR Corpus v1 [Data set]. Spectra Scientific LLC. Licensed under CC BY 4.0.

Creator: Ye Feng
Licensor: Spectra Scientific LLC
License: CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/)
